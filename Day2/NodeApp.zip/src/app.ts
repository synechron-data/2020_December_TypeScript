// console.log("Hello");

import * as http from 'http';
import { AddressInfo } from 'net';

const server = http.createServer((req, res) => {
    res.setHeader("content-type", "text/html");
    res.write("<h1>Response from Node Http Server</h1>");
    res.end();
});

server.listen(3000);

function onError(err: any) {
    console.log(err);
}

function onListening() {
    var address = server.address();
    console.log("Server started on port: ", (<AddressInfo>address).port);
}

server.on('error', onError);
server.on('listening', onListening);