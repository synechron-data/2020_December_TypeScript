// Implicitly Typed

// var data = 10;
// data = "ABC";           // Error: Type 'string' is not assignable to type 'number'.

// var s = "ABC";
// s = 10;                 // Error: Type 'number' is not assignable to type 'string'

// Variables created are optionally typesafe
// Untyped Variable - No Type Safety, No Intellisense
// var data;
// data = "ABC";
// data = 10;

// Explicitly Typed
// var age: number;
// age = 10;
// // age = "ABC"               // Error: Type 'string' is not assignable to type 'number'.

// var city: string;
// city = "Pune";

// function add(x: any, y: any) {
//     return x + y;
// }

// function add(x: number, y: number) {
//     return x + y;
// }

// console.log(add(2, 3));
// console.log(add(2, "ABC"));
// console.log(add("ABC", "XYZ"));

// var s: symbol = Symbol("Hello");
// var p: Promise<any> = new Promise((resolve, reject) => { });

// JavaScript Types and API's
// number / string / boolean / undefined / Array / Object / Date / RegExp / Function / void
// Based on target and lib section configured in in tsconfig.json

// TypeScript Types
// any / never / tuple / interface / enum / class / typeguards

var arr = [{ id: 1, name: "Manish" }];

var result = arr.find(x => x.id === 1);
console.log(result);