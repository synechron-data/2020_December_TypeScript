"use strict";
var empList;
empList = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Ram" },
    { id: 3, name: "Abhijeet" },
    { id: 4, name: "Pravin" },
    { id: 5, name: "Subodh" }
];
var nums = [10, 20, 30, 40, 50, 60, 70, 80, 90];
var sum = nums.reduce(function (total, num) { return total - num; });
console.log("Sum: ", sum);
