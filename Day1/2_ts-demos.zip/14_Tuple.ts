// Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence

// var arr1: number[] = [10, 20, 30, 40, 50];

// Typeguard Array
var arr2: (string | number)[] = ["Manish", 1];
arr2 = ["Abhijeet", "Pune"];
arr2 = [1, 2];
arr2 = [1, "Abhijeet"];
arr2 = [1, "Abhijeet", 411038, 38];

// Tuple
let dataRow: [number, string] = [1, "Manish"];
// dataRow = ["Abhijeet", "Pune"];
// dataRow = [1, 2];
// dataRow = ["Manish", 1];
// dataRow = [1, "Abhijeet", 411038, 38];

// console.log(dataRow[0]);
// console.log(dataRow[1]);

// for (const data of dataRow) {
//     console.log(data);
// }

function insert(data: [number, string]) {

}

insert([1, "Manish"]);
// insert([1]);
// insert(["Manish"]);
// insert(["Manish", 1]);

let dataRow1: [string, [string, number]];
dataRow1 = ["Manish", ["Pune", 411021]];