"use strict";
var arr = [{ id: 1, name: "Manish" }];
var result = arr.find(function (x) { return x.id === 1; });
console.log(result);
