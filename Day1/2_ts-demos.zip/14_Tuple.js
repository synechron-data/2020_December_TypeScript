"use strict";
var arr2 = ["Manish", 1];
arr2 = ["Abhijeet", "Pune"];
arr2 = [1, 2];
arr2 = [1, "Abhijeet"];
arr2 = [1, "Abhijeet", 411038, 38];
var dataRow = [1, "Manish"];
function insert(data) {
}
insert([1, "Manish"]);
var dataRow1;
dataRow1 = ["Manish", ["Pune", 411021]];
