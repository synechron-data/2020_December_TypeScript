// var arr1 = [10, 20, 30, 40, 50];

// var arr2: number[];
// arr2 = [10, 20, 30, 40, 50];

// var arr3: Array<number>;
// arr3 = [10, 20, 30, 40, 50];

// var arr4 = new Array("Manish");
// console.log(arr4);

// var arr5 = new Array(2);
// console.log(arr5);

// var arr6 = Array.of(2);
// console.log(arr6);

// var arr7 = Array.from("Manish");
// console.log(arr7);

var empList: Array<{ id: number, name: string }>;
empList = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Ram" },
    { id: 3, name: "Abhijeet" },
    { id: 4, name: "Pravin" },
    { id: 5, name: "Subodh" }
];

// for (let i = 0; i < empList.length; i++) {
//     console.log(`${i}       ${empList[i].name}`);
// }

// for (const key in empList) {
//     console.log(`${key}       ${empList[key].name}`);
// }

// empList.forEach((item, index, arr) => {
//     console.log(`${index}       ${item.name}`);
// });

// for (const item of empList) {
//     console.log(item.name);
// }

// for (const [index, item] of empList.entries()) {
//     console.log(`${index}       ${item.name}`);
// }

// var result1 = empList.filter(e => e.id === 5);
// console.log(result1);

// var result2 = empList.find(e => e.id === 5);
// console.log(result2);

// var result3 = empList.findIndex(e => e.id === 5);
// console.log(result3);

// var result4 = empList.map(e=>e.name.toUpperCase());
// console.log(result4);

// ------------------------------------------------------------------ Assignment

var nums = [10, 20, 30, 40, 50, 60, 70, 80, 90];

// var sum = nums.reduce((total, num) => total + num);
// var sum = nums.reduce((total, num) => total * num);
var sum = nums.reduce((total, num) => total - num);

console.log("Sum: ", sum);