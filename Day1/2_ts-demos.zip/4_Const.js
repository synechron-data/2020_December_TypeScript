"use strict";
var j;
j = 10;
j = 20;
var obj = { id: 1 };
console.log(obj);
obj.id = 1000;
console.log(obj);
