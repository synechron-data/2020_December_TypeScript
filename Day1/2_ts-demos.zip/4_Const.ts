let j;
j = 10;
j = 20;

// const env;      // Error: 'const' declarations must be initialized.

// const env = "production";
// console.log(env);

// env = "development";    // Error: Cannot assign to 'env' because it is a constant.
// console.log(env);

// const env = "development";    // Error: Cannot redeclare block-scoped variable 'env'
// console.log(env);

// if (true) {
//     const env = "development";
//     console.log("Inside Block: ", env);
// }

const obj = { id: 1 };
console.log(obj);

// obj = { name: "Manish" };           // Error: Cannot assign to 'obj' because it is a constant.
obj.id = 1000;
console.log(obj);

