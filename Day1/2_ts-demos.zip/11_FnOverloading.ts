// function hello() {
//     console.log("Hello World!");
// }

// function hello(name: string) {
//     console.log("Hello, ", name);
// }

// hello();
// hello("Manish");

// ---------------------------------------------
// function hello(): void;
// function hello(name: string): void;

// function hello(...args: string[]) {
//     function m1() {
//         console.log("Hello World!");
//     }

//     function m2(name: string) {
//         console.log("Hello,", name);
//     }

//     if (args.length == 0)
//         m1();
//     else
//         m2(args[0]);
// }

// hello();
// hello("Manish");
// hello("Abhijeet", "Gole");

// ---------------------------------------------
function hello(): void;
function hello(name: string): void;

function hello(...args: string[]) {
    if (args.length == 0)
        console.log("Hello World!");
    else
        console.log(`Hello, ${args[0]}`);
}

hello();
hello("Manish");