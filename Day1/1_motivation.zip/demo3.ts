class Person {
    private _name: string;

    constructor(name: string) {
        this._name = name;
    }

    getName() {
        return this._name;
    }

    setName(value: string) {
        this._name = value;
    }
}

var p1 = new Person("Manish");
console.log(p1.getName());
p1.setName("Abhijeet");
console.log(p1.getName());

var p2 = new Person("Pravin");
console.log(p2.getName());
p2.setName("Ramakant");
console.log(p2.getName());

// var p3 = new Person(10);
// console.log(p3.getName());
// p3.setName(true);
// console.log(p3.getName());

// Node Latest Should be installed
// npm install -g typescript (Global)
// tsc demo3.ts 